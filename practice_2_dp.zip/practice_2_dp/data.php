<?php

return [
    'about' => [
        'name' => 'Антон Филиппов',
        'post' => 'Менеджер',
        'email' => 'filanor@gmail.com',
        'phone' => '89261013733',
        'site' => 'unitef.ru'
    ],
    'education' => [
        [
            'faculty' => 'ИТ',
            'university' => 'МТУСИ',
            'yearStart' => 2015,
            'yearEnd' =>2018
        ],
        [
            'faculty' => 'Random faculty 2',
            'university' => 'Smth University 2',
            'yearStart' => 2010,
            'yearEnd' =>2015
        ]
    ],
    'languages' => [
        'English', 'Russian', 'French'
    ],
    'interests' => [
        'Настольные игры', 'Кино'
    ],
    'aboutCareer' => 'Закончил ВУЗ МТУСИ, но по профессии не пошел. Хотя были иногда заказы на верстку. Сейчас Решил подучиться, для фриланса',
    'career' => [
        [
            'start' => 2003,
            'finish' => 'настоящее время',
            'post' => 'менеджер',
            'place' => 'Москва',
            'duty' => 'Подача таможенных деклараций'
        ],
        [
            'start' => 2003,
            'finish' => 2003,
            'post' => 'техподдержка',
            'place' => 'Москва',
            'duty' => 'Помощь клиентам по телефонам'
        ]
    ],
    'projects' => [
        [
            'name' => 'tominert',
            'description' => 'Магазин по продаже майнеров. Верстка'
        ],
        [
            'name' => 'Русалют',
            'description' => 'Магазин по продаже фейерверков. Верстка'
        ]
    ],
    'skills' => [
        [
            'skill' => 'JavaScript',
            'level' => '60%'
        ],
        [
            'skill' => 'C++',
            'level' => '50%'
        ],
        [
            'skill' => 'Python',
            'level' => '30%'
        ]
    ]
];